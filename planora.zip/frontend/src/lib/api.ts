import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export const api = axios.create({
  baseURL: API_BASE,
})

// Auth
export const register = (username: string, password: string) =>
  api.post('/register', { username, password })

export const login = (username: string, password: string) =>
  api.post('/login', { username, password })

// Plans
export const generatePlan = (formData: FormData) =>
  api.post('/plan', formData)

export const savePlan = (plan: unknown, courseType: string, examDate: string, userId?: number) =>
  api.post('/save_plan', { plan: JSON.stringify(plan), course_type: courseType, exam_date: examDate, user_id: userId })

export const getPlan = (id: number) =>
  api.get(`/get_plan?id=${id}`)

export const listPlans = (userId?: number) =>
  api.get('/list_plans', { params: userId ? { user_id: userId } : {} })

export const updatePlan = (id: number, plan: unknown) =>
  api.post('/update_plan', { id, plan: JSON.stringify(plan) })

// Google Calendar
export const startGcalAuth = (planId?: number, userId?: number) =>
  api.get('/gcal_auth_start', { params: { ...(planId && { plan_id: planId }), ...(userId && { user_id: userId }) } })

export const pushToGcal = (events: unknown[], accessToken: string) =>
  api.post('/gcal_create', { events: JSON.stringify(events), access_token: accessToken })

export const revokeGcalAccess = (planId?: number, userId?: number) =>
  api.post('/gcal_revoke', { ...(planId && { plan_id: planId }), ...(userId && { user_id: userId }) })

// Export
export const exportPdf = (plan: unknown) =>
  api.post('/export_pdf', { plan: JSON.stringify(plan) }, { responseType: 'blob' })

export const getOcrStatus = () =>
  api.get('/ocr_status')
